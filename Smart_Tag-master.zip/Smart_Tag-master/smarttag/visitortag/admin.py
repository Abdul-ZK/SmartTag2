from django.contrib import admin
from .models import Visitor, Log

# Register your models here.
admin.site.register(Visitor)
admin.site.register(Log)