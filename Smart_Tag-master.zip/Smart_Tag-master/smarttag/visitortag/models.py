from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class Visitor(models.Model):
    name = models.CharField('Name', max_length=120, blank=True)
    address = models.CharField(max_length=300, blank=True)
    tag_no = models.CharField('Tag Number', max_length=15, blank=True)
    phone = models.CharField('Contact Phone', max_length=25, blank=True)
    gadget = models.CharField('Gadget', max_length=15, blank=True)
    time_in = models.DateTimeField('TimeIn', blank=True)
    time_out = models.DateTimeField('TimeOut', blank=True)

class Log(models.Model):
    anchor_id = models.CharField('Anchor ID', max_length=100, blank=True)
    beacon_id = models.CharField('Beacon ID', max_length=100, blank=True)
    rssi = models.CharField('RSSI', max_length=100, blank=True)
    timestamp = models.CharField('Timestamp', max_length=100, blank=True)

    def __str__(self):
        return self.name


