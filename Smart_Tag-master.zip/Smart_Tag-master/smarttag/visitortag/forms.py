from django import forms
from django.forms import ModelForm
from .models import forms, Visitor


class Registration(UserCreationForm):
    name = forms.CharField(max_length=120)
    address = forms.CharField(max_length=300)
    tag_no = forms.CharField(max_length=15)
    phone = forms.CharField(max_length=25, blank=True)
    gadget = forms.CharField(max_length=15)
    time_in = forms.DateTimeField(blank=True)
    time_out = forms.DateTimeField(blank=True)



class Meta:
    model = Visitor
    fields = ("name", "address", "Tag Number","Contact Phone", "Gadget", "TimeIn", "TimeOut")